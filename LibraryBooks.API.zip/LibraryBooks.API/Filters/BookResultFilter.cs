﻿using AutoMapper;
using LibraryBooks.API.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace LibraryBooks.API.Filters
{
    public class BookResultFilter : IAsyncResultFilter
    {
        private readonly IMapper _mapper;

        public BookResultFilter(IMapper mapper)
        {
           _mapper = mapper;
        }
        public async Task OnResultExecutionAsync(ResultExecutingContext context, ResultExecutionDelegate next)
        {
            var result = context.Result as ObjectResult;
            if (result?.Value == null || result.StatusCode < 200 || result.StatusCode >= 300)
            {
                await next();
                return;
            }
            result.Value = _mapper.Map<BookDto>(result.Value);

            await next();
        }
    }
}
