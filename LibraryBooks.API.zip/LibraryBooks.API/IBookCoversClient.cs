﻿internal interface IBookCoversClient
{
}