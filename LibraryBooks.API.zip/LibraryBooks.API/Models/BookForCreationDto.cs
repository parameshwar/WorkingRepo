﻿using System.ComponentModel.DataAnnotations;

namespace LibraryBooks.API.Models
{
    public class BookForCreationDto
    {

        [Required(ErrorMessage ="{0} is a mandatory field")]
        public Guid AuthorId { get; set; }

        [MaxLength(50,ErrorMessage ="The {0} cannot have more than {1} characters")]
        public string Title { get; set; }

        [MaxLength(50,ErrorMessage ="The {0} cannot have more than {1} characters")]
        public string? Description { get; set; }

        public BookForCreationDto(Guid authorId, string title, string? description)
        {
            AuthorId= authorId;
            Title= title;
            Description= description;
        }

    }
}
