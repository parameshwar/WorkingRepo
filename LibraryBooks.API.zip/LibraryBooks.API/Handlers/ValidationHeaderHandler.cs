﻿namespace LibraryBooks.API.Handlers
{
    public class ValidationHeaderHandler : DelegatingHandler
    {
        protected override  Task<HttpResponseMessage> SendAsync(HttpRequestMessage requestMessage, CancellationToken cancellationToken)
        {
            if(!requestMessage.Headers.Contains("Accept"))
            {
                var response = new HttpResponseMessage(System.Net.HttpStatusCode.BadRequest);
                var tsc = new TaskCompletionSource<HttpResponseMessage>();
                tsc.SetResult(response);
                return tsc.Task;
            }
            return  base.SendAsync(requestMessage, cancellationToken);
        }
        
    }
}
