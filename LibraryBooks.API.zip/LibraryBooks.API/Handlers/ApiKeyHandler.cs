﻿using System.Net;

namespace LibraryBooks.API.Handlers
{
    public class ApiKeyHandler : DelegatingHandler
    {
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
           var authKey = request?.Headers?.Authorization?.ToString();
            if (authKey == null)
            {
                var response = new HttpResponseMessage(HttpStatusCode.Unauthorized);
                var tsc = new TaskCompletionSource<HttpResponseMessage>();
                tsc.SetResult(response);
                return tsc.Task;
            }

            return base.SendAsync(request, cancellationToken);
        }
    }
}
