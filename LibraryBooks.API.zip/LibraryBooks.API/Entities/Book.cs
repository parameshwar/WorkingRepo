﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LibraryBooks.API.Entities
{
    public class Book
    {

        [Key]
        public Guid Id { get; set; }


        [Required]
        [MaxLength(250)]
        public string Title { get; set; }

        [MaxLength(2550)]
        public string? Description { get; set; }

        public Guid AuthorId { get; set; }
        public Author Author { get; set; } = null!;

        public Book(Guid id, Guid authorId, string title, string? description)
        {
            Id = id;
            Title = title;
            Description = description;
            AuthorId = authorId;
        }
    }
}
