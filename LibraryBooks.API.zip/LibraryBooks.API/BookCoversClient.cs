﻿public class BookCoversClient : IBookCoversClient
{
}