﻿namespace LibraryBooks.API
{
    public class BookSoureOptions
    {
        public const string SectionName = "BookSource";
        public string SourceCsvPath { get; set; }
    }
}