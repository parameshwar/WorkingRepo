﻿using Microsoft.Extensions.Configuration;

namespace LibraryBooks.API
{
    public static class DIRegistrations
    {
        public static IServiceCollection RegisterOptions(this IServiceCollection services)
        {
            services.AddOptions<BookSoureOptions>().Configure<IConfiguration>((options, configuration) =>
            {
                configuration.GetSection(BookSoureOptions.SectionName).Bind(options);
            });
            return services;
        }

        public static IApplicationBuilder UseApiKey(this IApplicationBuilder app)
        {
           return app.UseMiddleware<ApiKeyMiddleware>();
        }
    }
}
