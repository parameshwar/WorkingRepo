using LibraryBooks.API;
using LibraryBooks.API.DbContexts;
using LibraryBooks.API.Handlers;
using LibraryBooks.API.Services;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.AspNetCore.Mvc.Formatters;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

// Throttle the thread pool (set available threads to amount of processors)
ThreadPool.SetMaxThreads(Environment.ProcessorCount, Environment.ProcessorCount);

//builder.Services.AddControllers(options => options.RespectBrowserAcceptHeader = true).AddXmlSerializerFormatters().AddXmlDataContractSerializerFormatters();

//builder.Services.AddMvc()
//.AddMvcOptions(opt =>
//{
//    opt.OutputFormatters.Add(new XmlDataContractSerializerOutputFormatter());
//    opt.EnableEndpointRouting = false;
//}
//    );

//builder.Services.ConfigureMvc(options =>
//{
//    // This adds both Input and Output formatters based on DataContractSerializer
//    options.AddXmlDataContractSerializerFormatter();

//    // To add XmlSerializer based Input and Output formatters.
//    options.InputFormatters.Add(new XmlSerializerInputFormatter());
//    options.OutputFormatters.Add(new XmlSerializerOutputFormatter());
//});
builder.Services.AddControllers(configure =>
{
    configure.ReturnHttpNotAcceptable = true;
    configure.OutputFormatters.Add(new XmlDataContractSerializerOutputFormatter());
});
//.AddXmlDataContractSerializerFormatters();
builder.Services.AddTransient<ApiKeyHandler>();
builder.Services.AddTransient<ValidationHeaderHandler>();

builder.Services.AddHttpClient<IBookCoversClient, BookCoversClient>().ConfigureHttpClient(configure =>
{
    configure.BaseAddress = new Uri("http://localhost:5201/api/bookcovers");
}).AddHttpMessageHandler<ApiKeyHandler>().AddHttpMessageHandler<ValidationHeaderHandler>();

builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo { Title = "API EndPoints", Version = "V1" });
    
});

// register the DbContext on the container 
//builder.Services.AddDbContext<BooksDbContext>(options =>
//    options.UseSqlite(
//        builder.Configuration["ConnectionStrings:BooksDBConnectionString"]));

builder.Services.AddDbContext<BooksDbContext>();

builder.Services.AddScoped<IBooksRepository, BooksRepository>();

builder.Services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());

builder.Services.AddHealthChecks();

builder.Services.RegisterOptions();

var app = builder.Build();
if(app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "API EndPoints");
    });
    app.UseExceptionHandler(builder =>
    {
        builder.Run(async context =>
        {
            context.Response.StatusCode = 500;
            await context.Response.WriteAsync("An unexpected fault happened. Try again later");
        });
    });
}

if(!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/error");
    app.UseHsts();
}
// Configure the HTTP request pipeline.

app.UseHealthChecks("/health/live", new HealthCheckOptions
{
    Predicate = _ => false
});

app.UseApiKey();

app.UseAuthentication();

app.UseHealthChecks("/health/ready");

app.UseAuthorization();

app.MapControllers();

app.Run();
