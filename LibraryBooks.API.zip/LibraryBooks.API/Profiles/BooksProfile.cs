﻿using AutoMapper;
using LibraryBooks.API.Entities;
using LibraryBooks.API.Models;

namespace LibraryBooks.API.Profiles
{
    public class BooksProfile : Profile
    {
        public BooksProfile()
        {

            CreateMap<BookForCreationDto, Book>().ConstructUsing(x => new Book(Guid.NewGuid(), x.AuthorId, x.Title, x.Description));
            CreateMap<Book, BookDto>().ForMember(dest => dest.AuthorName, src => src.MapFrom(x => $"{x.Author.FirstName} {x.Author.LastName}"))
            .ConstructUsing(src => new BookDto(src.Id, string.Empty, src.Title, src.Description));
        }
    }
}
