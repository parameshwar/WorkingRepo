﻿namespace LibraryBooks.API.Controllers
{
    public static class BooksControllersHelpers
    {

        public static IEnumerable<string> Filter(this IEnumerable<string> strings, Func<string, bool> predicate)
        {
            foreach (var item in strings)
            {
                if (predicate(item))
                {
                    yield return item;
                }
            }
        }
    }
}