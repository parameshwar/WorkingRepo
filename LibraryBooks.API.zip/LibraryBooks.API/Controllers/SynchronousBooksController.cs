﻿using LibraryBooks.API.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace LibraryBooks.API.Controllers
{
    [Route("api")]
    [ApiController]
    public class SynchronousBooksController : ControllerBase
    {
        private readonly IBooksRepository _booksRepository;

        public SynchronousBooksController(IBooksRepository booksRepository)
        {
            _booksRepository = booksRepository;
        }

        [HttpGet("books/sync/{id}")]
        public IActionResult GetBook(Guid id)
        {
            var book = _booksRepository.GetBookById(id);
            return Ok(book);
        }


    }
}
