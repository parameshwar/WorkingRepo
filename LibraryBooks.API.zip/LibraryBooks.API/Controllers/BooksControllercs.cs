﻿using System.Runtime.CompilerServices;
using AutoMapper;
using LibraryBooks.API.Entities;
using LibraryBooks.API.Filters;
using LibraryBooks.API.Models;
using LibraryBooks.API.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace LibraryBooks.API.Controllers
{
    [Route("api/books")]
    [ApiController]
    public class BooksControllercs : ControllerBase
    {
        private readonly IBooksRepository _booksRepository;
        private readonly IMapper _mapper;
        private readonly IOptions<BookSoureOptions> _options;

        public BooksControllercs(IBooksRepository booksRepository, IMapper mapper, IOptions<BookSoureOptions> options)
        {
            _booksRepository = booksRepository ??
                throw new ArgumentNullException(nameof(booksRepository));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
            _options = options ?? throw new ArgumentNullException(nameof(options));
        }
        // GET: api/<BooksControllercs>
        [HttpGet]
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        [ApiExplorerSettings(IgnoreApi =true)]
        [Route("/error")]
        public IActionResult HandleError()
        {
           return Problem();
        }

        // GET api/<BooksControllercs>/5
        [HttpGet("{id}", Name="GetBook")]
        [TypeFilter(typeof(BookResultFilter))]
        public async Task<IActionResult> GetBook(Guid id, CancellationToken token)
        {
            //await Task.Delay(TimeSpan.FromSeconds(5), token);
            var book = await _booksRepository.GetBookAsync(id,token);
            if(book == null)
            {
                return NotFound();
            }
            return Ok(book);
        }

        // POST api/<BooksControllercs>
        [HttpPost]
        [TypeFilter(typeof(BookResultFilter))]
        [ProducesResponseType(StatusCodes.Status201Created)]
        public async Task<ActionResult<BookDto>> Post([FromBody] BookForCreationDto bookForCreationDto,CancellationToken token)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var bookEntity = _mapper.Map<Book>(bookForCreationDto);

            _booksRepository.AddBook(bookEntity,token);

           await _booksRepository.SaveChangesAsync(token);

            await _booksRepository.GetBookAsync(bookEntity.Id,token);
            
            return CreatedAtRoute("GetBook", new {id = bookEntity.Id}, bookEntity);
        }

        // PUT api/<BooksControllercs>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        [HttpGet("string/{id}")]
        public ActionResult<IEnumerable<string>> GetSring(int id)
        {
            string[] strings = new string[]
            {
                "red",
                "black",
                "yellow",
                "Green"
            };
            System.Diagnostics.Debugger.Break();
            var list = strings.Filter(x => x.Contains('e')).Take(1);
            foreach ( var item in list)
            {
                Console.WriteLine(item);
            }
            return Ok(list.ToList());
        }

        // DELETE api/<BooksControllercs>/5
        [HttpDelete("{id}")]
        public ActionResult<string> Delete(int id)
        {
            var bookCsvPath = _options.Value.SourceCsvPath;
            return Ok(bookCsvPath);
        }
    }
}
