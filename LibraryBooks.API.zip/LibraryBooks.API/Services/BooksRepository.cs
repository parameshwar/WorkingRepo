﻿using LibraryBooks.API.DbContexts;
using LibraryBooks.API.Entities;
using Microsoft.EntityFrameworkCore;

namespace LibraryBooks.API.Services
{
    public class BooksRepository : IBooksRepository
    {
        private readonly BooksDbContext _booksDbContext;

        public BooksRepository(BooksDbContext booksDbContext)
        {
            _booksDbContext = booksDbContext;
        }
        public void AddBook(Book book, CancellationToken token)
        {
            if(book == null)
            {
                throw new ArgumentNullException(nameof(book));
            }
           _booksDbContext.Add(book);
           //_booksDbContext.Database.ExecuteSqlInterpolatedAsync($"EXEC DeleteBooks {book.Id}");
        }

        public void DeleteBook(Book book)
        {

            _booksDbContext.Remove(book);
        }

        public async Task<Book?> GetBookAsync(Guid id, CancellationToken token)
        {
            return await _booksDbContext.Books.Where(x => x.Id == id).Include(b=>b.Author).FirstOrDefaultAsync(token);
        }

        public Book? GetBookById(Guid id)
        {
            return _booksDbContext.Books.Where(x => x.Id == id).Include(b => b.Author).FirstOrDefault();
        }

        public async Task<IEnumerable<Book>> GetBooksAsync(CancellationToken token)
        {
            return await _booksDbContext.Books.ToListAsync(token);
        }

        public Task<IEnumerable<Book>> GetBooksAsync(IEnumerable<Guid> ids)
        {
            throw new NotImplementedException();
        }

        public async Task<bool> SaveChangesAsync(CancellationToken token)
        {
           return (await _booksDbContext.SaveChangesAsync(token) >0);
        }

        public void UpdateBook(Book book)
        {
            throw new NotImplementedException();
        }
    }
}
