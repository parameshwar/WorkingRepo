﻿using LibraryBooks.API.Entities;

namespace LibraryBooks.API.Services
{
    public interface IBooksRepository
    {
        Task<IEnumerable<Book>> GetBooksAsync(IEnumerable<Guid> ids);

        Task<Book?> GetBookAsync(Guid id, CancellationToken token);

        Book? GetBookById(Guid id);

        void AddBook(Book book, CancellationToken token);

        void UpdateBook(Book book);
        void DeleteBook(Book book);

        Task<bool> SaveChangesAsync(CancellationToken token);

    }
}
