﻿using System.Runtime.Serialization;

namespace Books.API.Models;

[DataContract]
public class BookDto
{
    [DataMember]
    public Guid Id { get; set; }

    [DataMember]
    public string AuthorName { get; set; }
    [DataMember]
    public string Title { get; set; }

    [DataMember]
    public string? Description { get; set; }
 
    public BookDto(Guid id,
        string authorName,
        string title,
        string? description)
    {
        Id = id;
        AuthorName = authorName;
        Title = title;
        Description = description;
    }
}
