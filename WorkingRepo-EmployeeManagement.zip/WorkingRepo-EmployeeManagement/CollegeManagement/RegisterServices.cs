﻿using CollegeManagement.DataAccess.DbContexts;
using CollegeManagement.DataAccess.Services;

namespace CollegeManagement
{
    public static class RegisterServices
    {
        public static IServiceCollection ConfigureServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddControllers();
            services.AddDbContext<EmployeeDbContext>();
            services.AddScoped<ReaderFactory>();
            services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());
            services.AddScoped<IRepository>(c =>
            {
              return c.GetRequiredService<ReaderFactory>().GetReader(configuration["ReposityReaderType"]);
            });
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo { Version= "v1", Title="API Endpoints" });
            });
            return services;
        }
    }
}
