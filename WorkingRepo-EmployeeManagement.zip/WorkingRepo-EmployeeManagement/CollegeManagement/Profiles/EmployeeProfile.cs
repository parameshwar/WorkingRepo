﻿using AutoMapper;
using CollegeManagement.DataAccess.Entities;
using CollegeManagement.Models;

namespace CollegeManagement.Profiles
{
    public class EmployeeProfile : Profile
    {
        public EmployeeProfile() {

            CreateMap<EmployeeDTO, Employee>();
        }
    }
}
