﻿using System.Collections;
using AutoMapper;
using CollegeManagement.DataAccess.Entities;
using CollegeManagement.DataAccess.Services;
using CollegeManagement.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.Extensions.Logging;

namespace CollegeManagement.Controllers
{
    [Route("api/employees")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly IRepository _repository;
        private readonly IMapper _mapper;

        public EmployeeController(IRepository repository, IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }

        [HttpGet("{id}",Name ="GetEmployee")]
        public async Task<ActionResult<Employee>> GetEmployee(int id)
        {
            try
            {
                _repository.DeleteEmployee(id, new DataAccess.DbContexts.EmployeeDbContext());
                var entity = await _repository.GetEmployeeAsync(id);
                if(entity == null)
                {
                    return NotFound($"Employee Id-{id} is not found");
                }
                return Ok(entity);
            }
            catch (Exception ex)
            {
                //_logger.LogDebug(ex, string.Empty);
                return new EmptyResult();
            }
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Employee>>> GetAll()
        {
            try
            {
                var employees = await _repository.GetEmployeesAsync();
                if(employees == null)
                {
                    return NotFound();
                }
                return Ok(employees);
            }
            catch (Exception ex)
            {
                ModelState.AddModelStateException(ex);
                //_logger.LogError(ex, string.Empty);
                return new EmptyResult();
            }
        }

        [HttpPost]
        public async Task<ActionResult<Employee>> CreateEmployee(EmployeeDTO employeeDTO)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var entity = _mapper.Map<Employee>(employeeDTO);

                _repository.AddEmployee(entity);
                await _repository.SaveChangesAsync();

                return CreatedAtRoute("GetEmployee", new { id = entity.Id }, entity);
            }
            catch (Exception ex)
            {
                ModelState.AddModelStateException(ex);
                return BadRequest(ex.Message);
            }
        }
    }
}
