﻿using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace CollegeManagement.Controllers
{
    public static class MvcExtensions
    {

        public static void AddModelStateException(this ModelStateDictionary modelState, Exception exception)
        {
            modelState.AddModelError(string.Empty, exception.Message);
        }
    }
}