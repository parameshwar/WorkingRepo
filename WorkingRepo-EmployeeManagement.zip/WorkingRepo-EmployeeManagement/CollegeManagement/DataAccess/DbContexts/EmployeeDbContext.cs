﻿using CollegeManagement.DataAccess.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace CollegeManagement.DataAccess.DbContexts
{
    public class EmployeeDbContext : DbContext
    {
        private readonly IConfiguration configuration;

        public DbSet<Employee> Employees { get; set; }

        public DbSet<Address> Addresses { get; set; }
        //public EmployeeDbContext(IConfiguration configuration) {
        //    this.configuration = configuration;
        //}

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlite("Data Source = CollegeManagement.db");
            base.OnConfiguring(optionsBuilder);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }

    }
}
