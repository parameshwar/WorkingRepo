﻿using CollegeManagement.DataAccess.DbContexts;
using CollegeManagement.DataAccess.Entities;

namespace CollegeManagement.DataAccess.Services
{
    public static class RepositoryExtensions
    {
        public static void DeleteEmployee(this IRepository repository, int id, EmployeeDbContext employeeDbContext)
        {
            var entity = employeeDbContext.Employees.Where(x=>x.Id == id).FirstOrDefault();
            if(entity == null)
            {
                return;
            }
           employeeDbContext.Remove(entity);
           employeeDbContext.SaveChanges();
        }
    }
}
