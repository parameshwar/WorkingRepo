﻿using CollegeManagement.DataAccess.DbContexts;
using CollegeManagement.DataAccess.Entities;
using Microsoft.EntityFrameworkCore;

namespace CollegeManagement.DataAccess.Services
{
    public class CSVRepository : IRepository
    {
        private readonly EmployeeDbContext _employeeDbContext;

        public CSVRepository(EmployeeDbContext employeeDbContext)
        {
            _employeeDbContext = employeeDbContext;
        }

        //public CSVRepository() : base() { }
       

        public async Task<Employee?> GetEmployeeAsync(int employeeId)
        {
           return await _employeeDbContext.Employees.Where(x=>x.Id == employeeId).FirstOrDefaultAsync();
        }

        public async Task<IEnumerable<Employee>> GetEmployeesAsync()
        {
            return await _employeeDbContext.Employees.ToListAsync();
        }

        public void AddEmployee(Employee employee)
        {
            _employeeDbContext.Employees.Add(employee);
        }

        public async Task<bool> SaveChangesAsync()
        {
            return (await _employeeDbContext.SaveChangesAsync() > 0);
        }
    }
}