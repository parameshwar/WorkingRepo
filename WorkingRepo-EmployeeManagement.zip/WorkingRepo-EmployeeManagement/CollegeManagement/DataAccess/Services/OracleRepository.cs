﻿using CollegeManagement.DataAccess.DbContexts;
using CollegeManagement.DataAccess.Entities;

namespace CollegeManagement.DataAccess.Services
{
    public class OracleRepository : IRepository
    {
        private readonly EmployeeDbContext _employeeDbContext;

        public OracleRepository(EmployeeDbContext employeeDbContext)
        {
            _employeeDbContext = employeeDbContext;
        }

        public void AddEmployee(Employee employee)
        {
            throw new NotImplementedException();
        }

        public Task<Employee?> GetEmployeeAsync(int employeeId)
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<Employee>> GetEmployeesAsync()
        {
            throw new NotImplementedException();
        }

        public Task<bool> SaveChangesAsync()
        {
            throw new NotImplementedException();
        }
    }
}