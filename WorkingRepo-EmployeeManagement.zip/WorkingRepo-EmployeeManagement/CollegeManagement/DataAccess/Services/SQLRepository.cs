﻿using CollegeManagement.DataAccess.DbContexts;
using CollegeManagement.DataAccess.Entities;
using Microsoft.EntityFrameworkCore;

namespace CollegeManagement.DataAccess.Services
{
    public class SQLRepository : IRepository
    {
        private readonly EmployeeDbContext _employeeDbContext;

        //public SQLRepository()
        //{
        //    _employeeDbContext = new EmployeeDbContext();
        //}

        public SQLRepository(EmployeeDbContext employeeDbContext)
        {
            _employeeDbContext = employeeDbContext;
        }

        public void AddEmployee(Employee employee)
        {
            _employeeDbContext.Employees.Add(employee);
        }

        public async Task<Employee?> GetEmployeeAsync(int employeeId)
        {
            return await _employeeDbContext.Employees.Where(x => x.Id == employeeId).FirstOrDefaultAsync();   
        }

        public async Task<IEnumerable<Employee>> GetEmployeesAsync()
        {
            return await _employeeDbContext.Employees!.ToListAsync();
        }

        public async Task<bool> SaveChangesAsync()
        {
            return (await _employeeDbContext.SaveChangesAsync() > 0);
        }
    }
}