﻿using CollegeManagement.DataAccess.Entities;

namespace CollegeManagement.DataAccess.Services
{
    public interface IRepository
    {
        Task<IEnumerable<Employee>> GetEmployeesAsync();

        Task<Employee?> GetEmployeeAsync(int employeeId);

        void AddEmployee(Employee employee);

        Task<bool> SaveChangesAsync();
    }
}