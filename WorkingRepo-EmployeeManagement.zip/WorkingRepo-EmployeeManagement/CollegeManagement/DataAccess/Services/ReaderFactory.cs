﻿using CollegeManagement.DataAccess.DbContexts;

namespace CollegeManagement.DataAccess.Services
{
    public class ReaderFactory
    {
        private readonly EmployeeDbContext _employeeDbContext;

        public ReaderFactory(EmployeeDbContext employeeDbContext)
        {
            _employeeDbContext = employeeDbContext;
        }
        public IRepository GetReader(string? readerType)
        {
            switch (readerType)
            {
                case "SQL": return new SQLRepository(_employeeDbContext);
                case "CSV": return new CSVRepository(_employeeDbContext);
                case "Oracle": return new OracleRepository(_employeeDbContext);
                default:
                    throw new ArgumentException($"Invalid Argument type,{readerType}");
            }
        }
    }
}