﻿// See https://aka.ms/new-console-template for more information
/// <summary>
/// 
/// </summary>
public class Employee : IEmployee
{
    private readonly ILogger _logger;
    public Employee(ILogger logger)
    {
        _logger = logger ?? throw new ArgumentNullException(nameof(logger));
    }

    public void PerformWork(EmployeeBase employeeBase)
    {
        employeeBase.NoOfHoursWorked = ++ employeeBase.NoOfHoursWorked;
        _logger.LogDebug($"{employeeBase.EmployeeId} has worked for almost {employeeBase.NoOfHoursWorked} Hours");
    }
}