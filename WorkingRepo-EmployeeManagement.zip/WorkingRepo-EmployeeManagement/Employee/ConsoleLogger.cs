﻿// See https://aka.ms/new-console-template for more information
public class ConsoleLogger : ILogger
{
    public void LogDebug(string message)
    {
        Console.WriteLine(message);
        //Console.ReadLine();
    }
}