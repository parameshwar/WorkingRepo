﻿// See https://aka.ms/new-console-template for more information
public class EmployeeBase
{
    private double _noOfHoursWorked;

    //private double noOfHoursWorked;
    public string? Description { get; set; }
    public int EmployeeId { get; set; }
    //public int HourlyRate { get; set; }

    private int hourlyRate;

    public int HourlyRate
    {
        get { return hourlyRate; }
        set { hourlyRate = value; }
    }

    public string? Name { get; set; }
    public double NoOfHoursWorked
    {
        get { return _noOfHoursWorked; } 
        set
        {
            if(value < 10 && value > 0)
            {
                _noOfHoursWorked = 8;
            }
            else
            {
                _noOfHoursWorked = value < 0? 2: value;
            }
        } }

    public EmployeeBase(string name, string description, int employeeId, int hourlyRate, double noOfHoursWorked)
    {
        Name = name;
        Description = description;
        EmployeeId = employeeId;
        HourlyRate = hourlyRate;
        NoOfHoursWorked = noOfHoursWorked;
    }
    public EmployeeBase()
    {

    }

}