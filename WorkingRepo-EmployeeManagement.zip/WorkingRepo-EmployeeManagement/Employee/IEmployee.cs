﻿// See https://aka.ms/new-console-template for more information
public interface IEmployee
{
    void PerformWork(EmployeeBase employeeBase);
}