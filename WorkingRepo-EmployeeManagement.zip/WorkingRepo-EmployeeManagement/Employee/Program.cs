﻿// See https://aka.ms/new-console-template for more information
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

internal class Program
{
    private static void Main(string[] args)
    {
        Console.WriteLine("Hello, World!");

        var app = Host.CreateDefaultBuilder(args).ConfigureServices((context, services) =>
        {
            services.AddTransient<IEmployee, Employee>();
            services.AddTransient<ILogger, ConsoleLogger>();
        }).Build();

        var employee = app.Services.GetRequiredService<IEmployee>();
        employee.PerformWork(new EmployeeBase
        {
            EmployeeId= 1,
            HourlyRate= 1,
            Name="string",
            NoOfHoursWorked =-10,
        });
        //int i;
        //List<EmployeeBase> employeeBases = new();
        //for(i=0;i<10;i++)
        //{
        //    employeeBases.Add(new EmployeeBase("string", "string", 1, 1, 1));
        //}
        //employeeBases.Clear();
        //employeeBases = null;
        GC.Collect();
        Console.ReadLine();
    }
}