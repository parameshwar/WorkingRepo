﻿const double doub = 0.999;
Console.WriteLine(doub);
int month = 1;
month += 1;

Console.WriteLine(month);