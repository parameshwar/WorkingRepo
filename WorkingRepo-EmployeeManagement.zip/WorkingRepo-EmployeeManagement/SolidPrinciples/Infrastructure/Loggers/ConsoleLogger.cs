﻿// See https://aka.ms/new-console-template for more information

internal class ConsoleLogger : ILogger
{
    public void Log(string message)
    {
        Console.WriteLine(message);
    }
}   