﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArdalisRating;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using SolidPrinciples.Core.Interfaces;

namespace SolidPrinciples.Infrastructure.Serializers
{
    public class JsonPolicySerializer : IPolicySerializer
    {
        public Policy? GetPolicyFromSerializer(string policy)
        {
            return JsonConvert.DeserializeObject<Policy>(policy,
                new StringEnumConverter());
        }
    }
}
