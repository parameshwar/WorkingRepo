﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SolidPrinciples.Core.Interfaces;

namespace SolidPrinciples.Infrastructure.PolicySources
{
    public class FilePolicySource : IPolicySource
    {
        public string GetPolicyFromSource(string source)
        {
            return File.ReadAllText(source);
        } 
    }
}
