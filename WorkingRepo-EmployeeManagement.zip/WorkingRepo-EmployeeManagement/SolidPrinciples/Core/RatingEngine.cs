﻿using SolidPrinciples.Core.Interfaces;

namespace SolidPrinciples.Core
{
    public class RatingEngine
    {
        private readonly ILogger _logger;
        private readonly IPolicySerializer _policySerializer;
        private readonly IPolicySource _policySource;
        public decimal Rating { get; set; }

        public RatingEngine(ILogger logger, IPolicySerializer policySerializer, IPolicySource policySource)
        {
            _logger = logger;
            _policySerializer = policySerializer;
            _policySource = policySource;
        }

        public void Rate()
        {

            _logger.Log("Starting rate.");

            _logger.Log("Loading policy.");
            var policyjson = _policySource.GetPolicyFromSource("policy.json");
            var policy = _policySerializer.GetPolicyFromSerializer(policyjson);
            Rating = 1000;
            _logger.Log("Rating completed.");
        }

    }
}
