﻿namespace SolidPrinciples.Core.Interfaces
{
    public interface IPolicySource
    {
        string GetPolicyFromSource(string source);
    }
}