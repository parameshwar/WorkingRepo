﻿using ArdalisRating;

namespace SolidPrinciples.Core.Interfaces
{
    public interface IPolicySerializer
    {
       Policy? GetPolicyFromSerializer(string policy);
    }
}