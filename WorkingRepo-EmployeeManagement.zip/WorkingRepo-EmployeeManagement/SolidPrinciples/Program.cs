﻿// See https://aka.ms/new-console-template for more information

using System.Linq.Expressions;
using System.Text;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Newtonsoft.Json;
using SolidPrinciples;
using SolidPrinciples.Core;
using SolidPrinciples.Core.Interfaces;
using SolidPrinciples.Infrastructure.PolicySources;
using SolidPrinciples.Infrastructure.Serializers;


public class Program
{
    
    private static void Main(string[] args)
    {
        var host = Host.CreateDefaultBuilder(args).ConfigureServices((context, services) =>
{
    services.AddTransient<ILogger, ConsoleLogger>();
    services.AddTransient<IPolicySource, FilePolicySource>();
    services.AddTransient<IPolicySerializer, JsonPolicySerializer>();
    services.AddTransient<RatingEngine>();
}).Build();



        string json = @"[
{
'Name':'Product 1',
'Price':9.99
},
{
'Name':'Product 2',
'Price':10.99
}]";

        List<Product> products = JsonConvert.DeserializeObject<List<Product>>(json);
        Console.WriteLine(products?.Count);

        var json2 = JsonConvert.SerializeObject(products, Formatting.Indented);
        Console.WriteLine(json2);
        try
        {
            var path = @"C:\Users\smartbuildings\Documents\SolidSample-current\SolidSample-current\";
            var file = "product.txt";
            var finalPath = $"{path}{file}";
            StringBuilder sb = new StringBuilder();
            foreach (var product in products)
            {
                sb.Append($"Product Name: {product.Name} ;");
                sb.Append($"Product Price:{product.Price}");
                sb.Append(Environment.NewLine);
            }
            File.WriteAllText(finalPath, sb.ToString());
        }
        catch(DirectoryNotFoundException e)
        {
            Console.WriteLine(e.Message);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
        }

        const double interestRate = 0.07;
        double doubleMaxValue = double.MaxValue;
        var doubleMinValue = double.MinValue;
        Console.WriteLine(doubleMaxValue);
        Console.WriteLine(doubleMinValue);
       

        Char c = 'a';
        bool isDigit = Char.IsDigit(c);
        bool isLetter = Char.IsLetter(c);
        bool isLower = Char.IsLower(c);

        Console.WriteLine($"{isDigit}-{isLetter}-{isLower}");

        string a = "345.678";
        if (!double.TryParse(a, out double result))
        {
            Console.WriteLine(result);
        }

        DateTime dateTime = new DateTime(2017, 10, 10);
        dateTime.AddDays(25);
        var date1 = dateTime.AddMonths(3);
        Console.WriteLine(date1.ToLongDateString());
        Console.WriteLine(DateTime.Now);
        Console.WriteLine(DateTime.Today);
        var array = new int[] { 1, 2, 3, 4, };
        

        Expression<Func<int, int>> square = x=> x*x;
        //Console.WriteLine(square(3));cc
        Func<int, int, int> add = (x, y) => x + y;
        Action<int> write = x => Console.WriteLine(x);
        write(add(1, 2));
        Console.WriteLine(add(5,3));

        var numbers = new int[] { 1, 2,3,4, 5, 6, 7 };
        foreach (int number in numbers.Find(x=>x %2 ==0))
        {
            Console.WriteLine(number);
        }
        bool? accept = true;
        bool b = accept ?? false;
        Console.WriteLine(b);  // output: -1

        Console.ReadLine();



        //var rater = host.Services.GetRequiredService<RatingEngine>();
        //rater.Rate();
        //var rating = rater.Rating;
    }
}

public class Product
{
    public string Name { get; set; }
    public decimal Price { get; set; }
}


