﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArdalisRating;
using Moq;
using SolidPrinciples.Core;
using SolidPrinciples.Core.Interfaces;
using Xunit;

namespace SolidPrinciples.Test
{
    public class RatingEngineTest
    {
        private readonly Mock<ILogger> _logger;
        private readonly Mock<IPolicySerializer> _policySerializer;
        private readonly Mock<IPolicySource> _policySource;
        private readonly RatingEngine _ratingEngine;
        public RatingEngineTest()
        {
            _logger= new Mock<ILogger>();
            _policySerializer= new Mock<IPolicySerializer>();
            _policySource= new Mock<IPolicySource>();
            _ratingEngine = new RatingEngine(_logger.Object,_policySerializer.Object,_policySource.Object);
        }
        [Fact]
        public void RatingEngineMustReturn1000OnLandPolicy()
        {
            _policySource.Setup(x => x.GetPolicyFromSource(It.IsAny<string>())).Returns("policy");
            _policySerializer.Setup(x => x.GetPolicyFromSerializer(It.IsAny<string>())).Returns(new Policy());

            _ratingEngine.Rate();

            Assert.Equal(1000, _ratingEngine.Rating);
        }
    }
}
