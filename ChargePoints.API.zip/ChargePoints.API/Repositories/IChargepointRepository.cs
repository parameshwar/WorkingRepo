﻿using ChargePoints.API.Entities;

namespace ChargePoints.API.Repositories
{
    public interface IChargepointRepository
    {
        void AddChargepoint(Chargepoint? entity, CancellationToken token);
        void DeleteChargepoint(Chargepoint? entity, CancellationToken token);
        Task<IEnumerable<Chargepoint>> GetAllChargepoints(CancellationToken token);
        Task<Chargepoint?> GetChargepointById(Guid? id, CancellationToken token);

        Task<bool> SaveChangesAsync(CancellationToken token);
    }
}