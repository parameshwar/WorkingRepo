﻿using ChargePoints.API.DbContexts;
using ChargePoints.API.Entities;
using Microsoft.EntityFrameworkCore;

namespace ChargePoints.API.Repositories
{
    public class ChargepointRepository : IChargepointRepository
    {
        private readonly ChargePointsContext _chargepointsContext;

        public ChargepointRepository(ChargePointsContext chargepointsContext)
        {
            _chargepointsContext = chargepointsContext;
        }

        public async Task<IEnumerable<Chargepoint>> GetAllChargepoints(CancellationToken token)
        {
            return await _chargepointsContext.Chargepoints.ToListAsync(token);
        }

        public async Task<Chargepoint?> GetChargepointById(Guid? id, CancellationToken token)
        {
            if (id == null)
            {
                throw new ArgumentNullException(nameof(id));
            }

            return await _chargepointsContext.Chargepoints.Where(x => x.Id == id).FirstOrDefaultAsync(token);

        }

        public void AddChargepoint(Chargepoint? entity, CancellationToken token)
        {
            if (entity == null)
            {
                throw new ArgumentNullException($"{nameof(entity)} is null");
            }

            _chargepointsContext.Chargepoints.Add(entity);
        }

        public async void DeleteChargepoint(Chargepoint? entity, CancellationToken token)
        {
            if (entity == null)
            {
                throw new ArgumentNullException(nameof(entity));
            }
            var removeEntity = await _chargepointsContext.Chargepoints.Where(x => x.Id == entity.Id).FirstOrDefaultAsync(token);
            _chargepointsContext.Remove(removeEntity
                ?? throw new ArgumentNullException(nameof(removeEntity)));
        }

        public async Task<bool> SaveChangesAsync(CancellationToken token)
        {
            return (await _chargepointsContext.SaveChangesAsync(token) > 0);
        }

        public Task<List<Chargepoint>> GetChargepointsAsyncFromSQL(string text)
        {
            return  _chargepointsContext.Chargepoints.FromSqlRaw($"EXECUTE GetChargepoints {0}", text).ToListAsync();
        }
    }
}
