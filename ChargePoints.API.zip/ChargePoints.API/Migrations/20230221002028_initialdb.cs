﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace ChargePoints.API.Migrations
{
    /// <inheritdoc />
    public partial class initialdb : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Chargepoints",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "TEXT", nullable: false),
                    LastUpdateTime = table.Column<DateTime>(type: "TEXT", nullable: true),
                    IsOutOfService = table.Column<bool>(type: "INTEGER", nullable: false),
                    DateCommissioned = table.Column<DateTime>(type: "TEXT", nullable: true),
                    DateDeCommissioned = table.Column<DateTime>(type: "TEXT", nullable: true),
                    InstallationDate = table.Column<DateTime>(type: "TEXT", nullable: true),
                    UninstallationDate = table.Column<DateTime>(type: "TEXT", nullable: true),
                    InstalledFirmwareVersion = table.Column<string>(type: "TEXT", nullable: false),
                    IpAddress = table.Column<string>(type: "TEXT", nullable: false),
                    Port = table.Column<int>(type: "INTEGER", nullable: false),
                    SimId = table.Column<string>(type: "TEXT", nullable: false),
                    SingleConnectorAccess = table.Column<bool>(type: "INTEGER", nullable: false),
                    HeartbeatIntervalSeconds = table.Column<int>(type: "INTEGER", nullable: false),
                    PhoneNumber = table.Column<string>(type: "TEXT", nullable: false),
                    Deleted = table.Column<bool>(type: "INTEGER", nullable: false),
                    DeletedDateTime = table.Column<DateTime>(type: "TEXT", nullable: true),
                    SmsId = table.Column<string>(type: "TEXT", nullable: false),
                    PostId = table.Column<string>(type: "TEXT", nullable: false),
                    OtherPostIds = table.Column<string>(type: "TEXT", nullable: false),
                    MeterNumber = table.Column<string>(type: "TEXT", nullable: false),
                    CommsPassword = table.Column<string>(type: "TEXT", nullable: false),
                    PasswordEnabled = table.Column<bool>(type: "INTEGER", nullable: false),
                    Url = table.Column<string>(type: "TEXT", nullable: false),
                    ConfigPreset = table.Column<bool>(type: "INTEGER", nullable: false),
                    PostCode = table.Column<string>(type: "TEXT", nullable: false),
                    Lat = table.Column<double>(type: "REAL", nullable: false),
                    Long = table.Column<double>(type: "REAL", nullable: false),
                    FreeformInfo = table.Column<string>(type: "TEXT", nullable: false),
                    AcceptAnyRfid = table.Column<bool>(type: "INTEGER", nullable: true),
                    RfidMethod = table.Column<bool>(type: "INTEGER", nullable: false),
                    RemoteStartMethod = table.Column<bool>(type: "INTEGER", nullable: false),
                    ContactlessMethod = table.Column<bool>(type: "INTEGER", nullable: false),
                    EnableGireveLink = table.Column<bool>(type: "INTEGER", nullable: true),
                    EnableHubjectLink = table.Column<bool>(type: "INTEGER", nullable: true),
                    OcpiEnabled = table.Column<bool>(type: "INTEGER", nullable: false),
                    CommsConnectionEventTime = table.Column<DateTime>(type: "TEXT", nullable: true),
                    Tag1 = table.Column<string>(type: "TEXT", nullable: false),
                    Tag2 = table.Column<string>(type: "TEXT", nullable: false),
                    Tag3 = table.Column<string>(type: "TEXT", nullable: false),
                    DistributionPointReference = table.Column<string>(type: "TEXT", nullable: false),
                    ContactlessUnitId = table.Column<string>(type: "TEXT", nullable: false),
                    SerialNumber = table.Column<string>(type: "TEXT", nullable: false),
                    SmartChargingRegulationsApply = table.Column<bool>(type: "INTEGER", nullable: false),
                    EnableSmartChargingProfiles = table.Column<bool>(type: "INTEGER", nullable: false),
                    EnableRandomizedDelay = table.Column<bool>(type: "INTEGER", nullable: false),
                    CreationDate = table.Column<DateTime>(type: "TEXT", nullable: false),
                    LastModifiedDate = table.Column<DateTime>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Chargepoints", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Connectors",
                columns: table => new
                {
                    Id = table.Column<Guid>(type: "TEXT", nullable: false),
                    ConnectorId = table.Column<int>(type: "INTEGER", nullable: false),
                    LastErrorDate = table.Column<DateTime>(type: "TEXT", nullable: true),
                    FailedChargeCount = table.Column<int>(type: "INTEGER", nullable: false),
                    TargetConnectorChargingRate = table.Column<double>(type: "REAL", nullable: true),
                    TargetSoc = table.Column<double>(type: "REAL", nullable: true),
                    CurrentSoc = table.Column<double>(type: "REAL", nullable: true),
                    LastSoc = table.Column<double>(type: "REAL", nullable: true),
                    CurrentSocReported = table.Column<DateTime>(type: "TEXT", nullable: true),
                    AggregationRef = table.Column<string>(type: "TEXT", nullable: false),
                    DeviceCode = table.Column<string>(type: "TEXT", nullable: false),
                    IotHubKey = table.Column<string>(type: "TEXT", nullable: false),
                    LastActivePowerReading = table.Column<double>(type: "REAL", nullable: true),
                    LastActivePowerReadingSent = table.Column<DateTime>(type: "TEXT", nullable: true),
                    CreationDate = table.Column<DateTime>(type: "TEXT", nullable: false),
                    LastModifiedDate = table.Column<DateTime>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Connectors", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Connectors_Chargepoints_Id",
                        column: x => x.Id,
                        principalTable: "Chargepoints",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Connectors");

            migrationBuilder.DropTable(
                name: "Chargepoints");
        }
    }
}
