﻿using System.Runtime.CompilerServices;
using ChargePoints.API.DbContexts;
using ChargePoints.API.Repositories;

namespace ChargePoints.API
{
    public static class ConfigureServices
    {
        public static IServiceCollection ConfigureServiceCollection(this IServiceCollection services)
        {
            services.AddDbContext<ChargePointsContext>();
            services.AddScoped<IChargepointRepository,ChargepointRepository>();
            services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());
            services.AddHealthChecks();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new Microsoft.OpenApi.Models.OpenApiInfo { Version = "v1", Title = "Api Endpoints" });
            });
          return services;
        }
    }
}
