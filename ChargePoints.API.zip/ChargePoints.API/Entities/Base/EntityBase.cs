﻿using System;

namespace ChargePoints.API.Entities.Base
{
    public abstract class EntityBase
    {
        public  Guid Id { get; set; }
        public  DateTime CreationDate { get; set; }
        public  DateTime LastModifiedDate { get; set; }
    }
}