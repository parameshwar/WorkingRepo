namespace ChargePoints.API.Entities.Base
{
    public interface IHasPostalAddress
    {
        string Line1 { get; set; }
        string Line2 { get; set; }
        string Line3 { get; set; }
        string PostTown { get; set; }
        string County { get; set; }
        string Postcode { get; set; }
        string Country { get; set; }
    }
}