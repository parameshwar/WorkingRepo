using System;

namespace ChargePoints.API.Entities.Base
{
    public interface ISoftDeletable
    {
        bool Deleted { get; set; }
        DateTime? DeletedDateTime { get; set; }
    }
}