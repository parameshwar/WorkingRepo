//using System;
//using System.Collections.Generic;
//using ChargePoints.API.Enumerations;

//namespace ChargePoints.API.Entities.Base
//{
//    public interface IHasRoles
//    {
//        ICollection<Role> Roles { get; set; }
//    }
//}