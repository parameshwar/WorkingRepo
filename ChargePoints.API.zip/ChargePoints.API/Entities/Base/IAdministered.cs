//using System;
//using System.Collections.Generic;

//namespace ChargePoints.API.Entities.Base
//{
//    public interface IAdministered
//    {
//        Organisation AdministeredByOrganisation { get; set; }
//    }
//}