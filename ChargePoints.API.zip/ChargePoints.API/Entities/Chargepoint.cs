﻿using ChargePoints.API.Entities.Base;

namespace ChargePoints.API.Entities
{
    public class Chargepoint : EntityBase, ISoftDeletable
    {
        
        //public  GenieStatus LastStatus { get; set; }
        
        public  DateTime? LastUpdateTime { get; set; }

        public  bool IsOutOfService { get; set; }
        public  DateTime? DateCommissioned { get; set; }
        public  DateTime? DateDeCommissioned { get; set; }
        public  DateTime? InstallationDate { get; set; }
        public  DateTime? UninstallationDate { get; set; }
        public  string InstalledFirmwareVersion { get; set; }
        public  string IpAddress { get; set; }
        public  int Port { get; set; }
        //public  OcppVersion OcppVersion { get; set; }
        //public  ApnType ApnType { get; set; }
        public  string SimId { get; set; }
        public  bool SingleConnectorAccess { get; set; }

        public  int HeartbeatIntervalSeconds { get; set; }
        public  string PhoneNumber { get; set; }
        public  bool Deleted { get; set; }
        public  DateTime? DeletedDateTime { get; set; }
        public  string SmsId { get; set; }
        public  string PostId { get; set; }
        //public  Location Location { get; set; }
        //public  Scheme Scheme { get; set; }
        public  string OtherPostIds { get; set; }
        public  string MeterNumber { get; set; }
        public  string CommsPassword { get; set; }
        public  bool PasswordEnabled { get; set; }
        public  string Url { get; set; }
        public  bool ConfigPreset { get; set; }


        public  string PostCode { get; set; }

        public  double Lat { get; set; } = 0;

        public  double Long { get; set; } = 0;

        public  string FreeformInfo { get; set; } = string.Empty;

         public  IList<Connector> Connectors { get; set; }

        public  bool? AcceptAnyRfid { get; set; }

        // public  IList<ChargepointConfigurationItem> ConfigurationItems { get; set; }

        // public  ICollection<ChargepointUsageRestrictions> UsageRestrictions { get; set; }

        //public  ChargepointPlatform Platform { get; set; }

        //public  string Emi3Id { get; set; }

        //public  AggregationProvider AggregationPartner { get; set; }

        public  bool RfidMethod { get; set; }

        public  bool RemoteStartMethod { get; set; }

        public  bool ContactlessMethod { get; set; }

        //public  ChargepointVariant ChargepointVariant { get; set; }

        //public  EndpointType EntityEndpointType { get; set; }

         //public  ICollection<EnergyMeter> EnergyMeters { get; set; }

        public  bool? EnableGireveLink { get; set; }
        public  bool? EnableHubjectLink { get; set; }

        public  bool OcpiEnabled { get; set; }

        public  DateTime? CommsConnectionEventTime { get; set; }
        //public  CommsStatus CommsConnectionStatus { get; set; }
        //public  CommsConnectionType CommsConnectionType { get; set; }

        /// <summary>
        /// These fields are for user defined tags on chargepoints.
        /// They can represent anything the organisation wants it to represent
        /// </summary>
        public  string Tag1 { get; set; }
        public  string Tag2 { get; set; }
        public  string Tag3 { get; set; }
        
        public  string DistributionPointReference { get; set; }
        public  string ContactlessUnitId { get; set; }

        //public  Spf Spf { get; set; }
        public  string SerialNumber { get; set; }

        public  bool SmartChargingRegulationsApply { get; set; }
        public  bool EnableSmartChargingProfiles { get; set; }
        public  bool EnableRandomizedDelay { get; set; }

        public Chargepoint()
        {
            //Location = new Location();
            //Scheme = new Scheme();
            Connectors = new List<Connector>();
            //EnergyMeters = new List<EnergyMeter>();
        }

        //public  ConnectorSpeed FastestConnectorSpeed
        //{
        //    get
        //    {
        //        if (Connectors == null || Connectors.Count == 0)
        //        {
        //            return ConnectorSpeed.Undefined;
        //        }

        //        if (Connectors.Any(c => c.ConnectorSpeed() == ConnectorSpeed.Rapid))
        //        {
        //            return ConnectorSpeed.Rapid;
        //        }

        //        if (Connectors.Any(c => c.ConnectorSpeed() == ConnectorSpeed.Fast))
        //        {
        //            return ConnectorSpeed.Fast;
        //        }

        //        return ConnectorSpeed.Slow;
        //    }
        //}
    }
}