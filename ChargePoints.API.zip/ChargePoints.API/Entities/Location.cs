﻿//using System;
//using System.Collections.Generic;
//using ChargePoints.API.Entities.Base;
//using ChargePoints.API.Enumerations;

//namespace ChargePoints.API.Entities
//{
//    public class Location : EntityBase, ISoftDeletable, IAdministered
//    {
//        public Location()
//        {
//            Chargepoints = new List<Chargepoint>();
//        }
//        public  double Longitude { get; set; }
//        public  double Latitude { get; set; }
//        public  string Postcode { get; set; }
//        public  string Description { get; set; }
//        public  string Street { get; set; }
//        public  string City { get; set; }
//        public  string Notes { get; set; }
//        public  bool Deleted { get; set; }
//        public  DateTime? DeletedDateTime { get; set; }
//        public  IList<Chargepoint> Chargepoints { get; set; } 
//        public  string CountryCode { get; set; } = String.Empty;
//        public  string County { get; set; }
//        public  string Locality { get; set; }
//        public  string StreetmapView { get; set; }
//        public  string BirdseyeView { get; set; }
//        public  string Contact { get; set; }
//        public  string Reference { get; set; }
//        public  bool QueueEnabled { get; set; }
//        public  ChargepointPlatform Platform { get; set; }
//        //public  Organisation AdministeredByOrganisation { get; set; }
//        public  byte[] LocationImage { get; set; }
//        public  byte[] ThumbnailImage { get; set; }
//        public  string ContactTitle { get; set; }
//        public  string ContactName { get; set; }
//        public  string ContactNumber { get; set; }
//        public  string ContactEmail { get; set; }
//    }
//}