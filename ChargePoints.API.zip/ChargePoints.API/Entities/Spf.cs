﻿//using System;
//using ChargePoints.API.Entities.Base;
//using ChargePoints.API.Enumerations;

//namespace ChargePoints.API.Entities
//{
//    public class Spf : EntityBase
//    {
//        public  SpfStatus SpfStatus { get; set; }
//         //public  Quote Quote { get; set; }
//        public  Scheme Scheme { get; set; }
//        //public  User CreatedBy { get; set; }
//        //public  Organisation Organisation { get; set; }
//        //public  User SubmittedBy { get; set; }
//        public  DateTime? DateSubmitted { get; set; }
//        public  string SpfReference { get; set; }
//        public  string ClientCompanyName { get; set; }
//        public  string ClientFullName { get; set; }
//        public  string ClientEmail { get; set; }
//        public  string ClientTelephone { get; set; }
//        public  string ClientAddress { get; set; }
//        public  string ClientPostcode { get; set; }
//        public  string CommissioningEngineerName { get; set; }
//        public  string CommissioningEngineerEmail { get; set; }
//        public  DateTime? CommissioningDate { get; set; }
//        public  string ProjectDeliveryManager { get; set; }
//        public  string SimsAndStickersDispatchDetails { get; set; }
//        public  DateTime? SimsAndStickerRequiredByDate { get; set; }
//        public  string DashboardContactName { get; set; }
//        public  string DashboardContactEmail { get; set; }
//        public  string DashboardContactTelephone { get; set; }
//        public  string DashboardContactAddress { get; set; }
//        public  string DashboardContactPostcode { get; set; }
//        public  string OlevGrantVoucherCode { get; set; }
//        public  DateTime? OlevGrantExpiryDate { get; set; }
//        public  SpfSchemeDetailsType SchemeDetails { get; set; }
//        public  SpfAccessType SchemeAccessType { get; set; }
//        public  SpfPaymentType PaymentType { get; set; }
//        public  SpfAssetOwnershipType AssetOwnershipType { get; set; }
//        public  SpfHostAgreement HostAgreementType { get; set; }
//        public  Boolean CustomerRequired247 { get; set; }
//        public  decimal TariffAdminFeeRapid { get; set; }
//        public  decimal TariffCustomerCareFeeRapid { get; set; }
//        public  decimal TariffDriverConnectionFeeRapid { get; set; }
//        public  decimal TariffDriverKwhRapid { get; set; }
//        public  decimal TariffOverstayFeeRapid { get; set; }
//        public  int TariffOverstayDurationMinutesRapid { get; set; }
//        public  decimal TariffAdminFeeFast { get; set; }
//        public  decimal TariffCustomerCareFeeFast { get; set; }
//        public  decimal TariffDriverConnectionFeeFast { get; set; }
//        public  decimal TariffDriverKwhFast { get; set; }
//        public  decimal TariffOverstayFeeFast { get; set; }
//        public  int TariffOverstayDurationMinutesFast { get; set; }
//        public  int NumberOfCardsRequired { get; set; }
//        public  DateTime? CommissioningFormsSentDate { get; set; }
//        public  Boolean OlevGrantClaimed { get; set; }
//    }
//}