﻿using System;
using ChargePoints.API.Entities.Base;

namespace ChargePoints.API.Entities
{
    public class Connector : EntityBase
    {
        /// <summary>
        /// Updated The number of the connector, 0 = whole chargepoint
        /// </summary>
        public  int ConnectorId { get; set; }

        //public  GenieStatus GenieStatus { get; set; }
        //public  GenieStatus ReportedStatus { get; set; }
        //public  string ConnectorErrorCode { get; set; }
        //public  string VendorErrorCode { get; set; }
        //public  DerivedStatus ErrorStatus { get; set; }
        public  DateTime? LastErrorDate { get; set; }
        public  int FailedChargeCount { get; set; }
        public  Chargepoint Chargepoint { get; set; }

        public Guid Id { get; set; }
        //public  ChargingRateUnit? ConnectorChargingRateUnit { get; set; }
        //public  double? ConnectorChargingRate { get; set; }
        //public  ChargingRateUnit? TargetConnectorChargingRateUnit { get; set; }
        public  double? TargetConnectorChargingRate { get; set; }
        //public  ChargepointPlatform Platform { get; set; }
        //public  string EvseId { get; set; }

        //public  PowerType ConnectorPowerType { get; set; }
        //public  double ConnectorKwh { get; set; }
        //public  double? PotentialConnectorKw { get; set; }
        //public  ConnectorShape ConnectorShape { get; set; }

        //public  SessionType ChargeType { get; set; }
        public  double? TargetSoc { get; set; }
        public  double? CurrentSoc { get; set; }
        public  double? LastSoc { get; set; }
        //public  GenieStatus? LastStatus { get; set; }
        public  DateTime? CurrentSocReported { get; set; }
        public  string AggregationRef { get; set; }
        public  string DeviceCode { get; set; }
        public  string IotHubKey { get; set; }
        public  double? LastActivePowerReading { get; set; }
        public  DateTime? LastActivePowerReadingSent { get; set; }
    }
}