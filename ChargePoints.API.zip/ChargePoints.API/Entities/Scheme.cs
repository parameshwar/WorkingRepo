﻿//using System;
//using System.Collections.Generic;
//using System.Diagnostics;
//using ChargePoints.API.Entities.Base;
//using ChargePoints.API.Enumerations;

//namespace ChargePoints.API.Entities
//{
//    [DebuggerDisplay("Name = {Name}, Id = {Id}, Whitelists = {Whitelists.Count}")]
//    public class Scheme : EntityBase
//    {
//        public  string Name { get; set; }
//        public  bool IsGeniePublic { get; set; }
//        public  string Contact { get; set; }
//        public  ICollection<Chargepoint> Chargepoints { get; set; }
//        //public  ICollection<Whitelist> Whitelists { get; set; }
//        //public  ICollection<Card> Cards { get; set; }
//        //public  ICollection<TariffSelection> TariffSelections { get; set; }
//        public  ChargepointPlatform Platform { get; set; }
//        //public  ICollection<SchemeInteroperationGroup> InteropGroups { get; set; }
//        //public  ICollection<SchemeFee> SchemeFees { get; set; }

//        public  bool AcceptAnyRfid { get; set; }

//        //public  Organisation AdministeredByOrganisation { get; set; }

//        //public  DiscountCategory DefaultDiscountCategory { get; set; }

//        public  bool EnableGireveLink { get; set; }
//        public  bool EnableHubjectLink { get; set; }

//        public  bool OcpiEnabled { get; set; }
//        public  bool PlugAndPlayEnabled { get; set; }

//        public Scheme()
//        {
//            Chargepoints = new List<Chargepoint>();
//            //Whitelists = new List<Whitelist>();
//            //Cards = new List<Card>();
//            //TariffSelections = new List<TariffSelection>();
//        }
//    }
//}