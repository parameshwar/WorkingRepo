﻿using AutoMapper;
using ChargePoints.API.Entities;
using ChargePoints.API.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace ChargePoints.API.Controllers
{
    [Route("api/chargepoints")]
    [ApiController]
    public class ChargepointsController : ControllerBase
    {
        private readonly IChargepointRepository _chargepointRepository;
        private readonly IMapper _mapper;

        public ChargepointsController(IChargepointRepository chargepointRepository, IMapper mapper)
        {
            _chargepointRepository = chargepointRepository ?? throw new ArgumentNullException(nameof(chargepointRepository));
            _mapper = mapper ?? throw new ArgumentNullException(nameof(mapper));
        }

        [HttpGet("{id}", Name ="GetChargepoint")]
        public async Task<ActionResult<Chargepoint>> GetChargepoint(Guid id, CancellationToken token)
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            var entity = await _chargepointRepository.GetChargepointById(id,token);
            return Ok(entity);
        }

        [HttpPost]
        public async Task<ActionResult<Chargepoint>> CreateChargepoint(Chargepoint chargepoint, CancellationToken token)
        {
            if(!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            _chargepointRepository.AddChargepoint(chargepoint, token);
            await _chargepointRepository.SaveChangesAsync(token);
            return CreatedAtRoute("GetChargepoint", new { id = chargepoint.Id }, chargepoint);
        }
    }
}
