﻿using ChargePoints.API.Entities;
using Microsoft.EntityFrameworkCore;

namespace ChargePoints.API.DbContexts
{
    public class ChargePointsContext: DbContext
    {

        private readonly IConfiguration _configuration;
        public static ILoggerFactory factory = LoggerFactory.Create(configure => configure.AddConsole());
        public DbSet<Chargepoint> Chargepoints { get; set; }
        public DbSet<Connector> Connectors { get; set; }

        public ChargePointsContext(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseLoggerFactory(factory);

            optionsBuilder.UseSqlite(_configuration.GetConnectionString("ChargepointsDBConnectionString"));
           
            base.OnConfiguring(optionsBuilder);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Connector>().HasOne(x => x.Chargepoint)
                .WithMany(g => g.Connectors).HasForeignKey(x=>x.Id);

           

            base.OnModelCreating(modelBuilder);
        }
    }
}
