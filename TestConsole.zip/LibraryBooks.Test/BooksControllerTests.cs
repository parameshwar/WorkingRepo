﻿using AutoMapper;
using LibraryBooks.API;
using LibraryBooks.API.Controllers;
using LibraryBooks.API.Entities;
using LibraryBooks.API.Models;
using LibraryBooks.API.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Moq;
using Xunit;

namespace LibraryBooks.Test
{
    public class BooksControllerTests
    {
        private readonly Mock<IBooksRepository> _booksRepository;
        private readonly Mock<IMapper> _mapper;
        private readonly BooksControllercs _booksControllercs;
        private readonly Mock<IOptions<BookSoureOptions>> _options;

        public BooksControllerTests()
        {
            _booksRepository = new Mock<IBooksRepository>();
            _mapper = new Mock<IMapper>();
            _options = new Mock<IOptions<BookSoureOptions>>();
            _booksControllercs = new BooksControllercs(_booksRepository.Object, _mapper.Object,_options.Object);
        }

        [Fact]
        public async Task GetBook_GetAction_MustReturnOkObjectResult()
        {
            //Arrange
            _booksRepository.Setup(x => x.GetBookAsync(It.IsAny<Guid>(),CancellationToken.None)).ReturnsAsync(new API.Entities.Book(Guid.Empty, Guid.Empty, "Tom", "Honks"));

            var result = await _booksControllercs.GetBook(Guid.Empty,CancellationToken.None);

            var actionResult = Assert.IsType<OkObjectResult>(result);
            var returnValue = Assert.IsType<Book>(actionResult.Value);
            Assert.NotNull(returnValue);
        }

        [Fact]
        public async Task Post_PostAction_ReturnsBadRequestOnInvalidInput()
        {
            _booksControllercs.ModelState.AddModelError("505", "Empty string in the Title field");

            var result = await _booksControllercs.Post(new API.Models.BookForCreationDto(Guid.Empty,"",""), CancellationToken.None);

           var actionResult = Assert.IsType<BadRequestObjectResult>(result);
           Assert.IsType<SerializableError>(actionResult.Value);

        }

        [Fact]
        public async Task Post_PostAction_MustReturnOkObjectResult()
        {
            _mapper.Setup(x => x.Map<Book>(new BookForCreationDto(Guid.NewGuid(),"",""))).Returns(new Book(Guid.NewGuid(), Guid.Empty, "title", ""));
            _booksRepository.Setup(x => x.AddBook(It.IsAny<Book>(),CancellationToken.None));

            var result = await _booksControllercs.Post(new BookForCreationDto(Guid.Empty, "title", "description"), CancellationToken.None);

            var actionResult = Assert.IsType<OkObjectResult>(result);
            Assert.NotNull(actionResult.Value);

        }
    }
}
