﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");

int maxValue = int.MaxValue;
int minValue = int.MinValue;

char userSelection = 'a';

bool isUpper = char.IsUpper(userSelection);

bool isDigit = char.IsDigit(userSelection);

bool isLetter = char.IsLetter(userSelection);



DateTime dateTime= DateTime.Now;

Console.WriteLine(dateTime.ToString());

DateTime hireDate = new DateTime(2017, 03, 28, 22, 17, 0);
Console.WriteLine(hireDate);
DateTime startDate = hireDate.AddHours(8);

Console.WriteLine(startDate);

DateTime quiteDate = hireDate.AddDays(15);

var startTime = quiteDate.AddHours(8);

TimeSpan endtime = new TimeSpan(8, 30, 0);

Console.WriteLine((quiteDate - hireDate).TotalHours);

Console.WriteLine(startTime.ToString());

Console.WriteLine(startTime.ToLongDateString());

DateTime? start = new DateTime(2300,04,26);

if(start.HasValue)
{
    Console.WriteLine(start.Value);
}

string a = "123.234";
bool parsed = double.TryParse(a, out double result);

Console.WriteLine($"{parsed}-{result}");
Console.ReadLine();


